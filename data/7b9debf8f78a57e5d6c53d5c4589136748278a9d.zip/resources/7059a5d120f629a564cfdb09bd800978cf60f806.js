'use strict';

Bs.define('Module.Digipost.Model.DigipostRoutingFlowEntry', {
    apiResource: 'module/digipost/digipostRoutingFlowEntry',
    pk         : 'employeeDocumentId',
    extend     : 'Bs.Model',
    fields     : {
        employeeDocumentId     : null,
        digipostRoutingFlowId  : null,
        providerId             : null,
        state                  : null,
        providerErrorMessage   : null,
        paypostInvoiceArticleId: null,
        createdAt              : null,
        updatedAt              : null
    },
    relations  : {
        paypostInvoiceArticle: 'Module.Paypost.Model.PaypostInvoiceArticle'
    }
});
