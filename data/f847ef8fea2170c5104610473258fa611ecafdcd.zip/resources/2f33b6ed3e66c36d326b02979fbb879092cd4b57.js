'use strict';

Bs.define('Module.DocumentArchive.Collection.DocumentArchives', {
    extend: 'Bs.Collection',
    model : 'Module.DocumentArchive.Model.DocumentArchive'
});
