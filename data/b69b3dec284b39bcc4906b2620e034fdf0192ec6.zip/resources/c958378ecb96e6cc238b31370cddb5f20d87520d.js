Bs.define('Module.Formation.App', {
    extend: 'Util.Module',
    initialize: function Module() {
        page('/page/createTree', () => {
            Bs.require('Module.Formation.View.Tree', function (create) {
                create({
                    renderTo: $('#main').empty(),
                });
            });
        });
    }
});
