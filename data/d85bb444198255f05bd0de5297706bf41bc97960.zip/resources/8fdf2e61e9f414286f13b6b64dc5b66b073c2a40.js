'use strict';

Bs.define('Module.DocumentArchive.Model.DocumentArchive', {
    extend   : 'Bs.Model',
    pk       : ['id'],
    fields   : {
        id        : null,
        documentId: null,
        status    : null
    },
    relations: {
        document: 'Model.Document'
    },
    getStatusTranslated   : function () {
        return Bs.Lang.t('Module/DocumentArchive/View/Search:status.' + this.get('status'));
    },
});
