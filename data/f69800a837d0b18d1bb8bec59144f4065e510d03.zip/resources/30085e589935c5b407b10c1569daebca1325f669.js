'use strict';

Bs.define('Bundle.Document.App', {
    extend: 'Util.Module',

    initialize: function Bundle () {
        var me = this;

        me.handleEvents();
    },

    handleEvents: function () {
        $(document).on('document.viewer.initialize', function (e, documentObj) {
            if (!documentObj.hasRight('documentDownload') && !My.Profile.isAdmin()) {
                // Hide PDFViewer download button.
                $(document).on('pdfViewer.afterRender', function (e, me) {
                    $(me.getViewerConfiguration().toolbar.download).hide();
                });
                // Prevent PDFViewer download. Ex : By pressing ctrl+s
                $(document).on('pdfViewer.viewer.download', function (e, preventRights) {
                    preventRights.download = true;
                });
                // Prevent PDFViewer save, not sure whats triggers 'save' event in PDFViewer.
                $(document).on('pdfViewer.viewer.save', function (e, preventRights) {
                    preventRights.save = true;
                });
            }
        });

        $(document).on('actions.document', function (e, buttonList, document) {
            if (document.hasRight('documentDownload')) {
                buttonList.push({
                    id      : 'documentDownload',
                    text    : 'Télécharger',
                    i18n    : 'telecharger_document',
                    icon    : 'fas fa-file-download',
                    onclick : 'documentDownload(' + document.get('id') + ', "document")',
                    cls     : 'documentDownload',
                    priority: 2,
                    badge   : 0,
                    dropdown: ''
                });
            }
            if (document.hasRight('documentPublic') && My.Profile.hasFeature('documentPublic')) {
                buttonList.push({
                    id      : 'documentPublic',
                    text    : 'Partager',
                    i18n    : 'share',
                    icon    : 'fas fa-share-alt',
                    cls     : 'documentPublic',
                    priority: 8,
                    badge   : 0,
                    dropdown: ''
                });
            }

            if (document.hasRight('renommerDocument')) {
                buttonList.push({
                    id      : 'documentRename',
                    text    : 'Renommer',
                    i18n    : 'renommer',
                    icon    : 'fas fa-pencil-alt',
                    onclick : 'prepareRenommer(' + document.get('id') + ', "document")',
                    cls     : 'documentRename',
                    priority: 12,
                    badge   : 0,
                    dropdown: ''
                });
            }
            if (document.hasRight('supprimerDocument')) {
                buttonList.push({
                    id      : 'documentMove',
                    text    : 'Déplacer',
                    i18n    : 'move',
                    icon    : 'fas fa-arrows-alt',
                    cls     : 'documentMove',
                    priority: 6,
                    badge   : 0,
                    dropdown: ''
                });
                if (document.get('archiveId') === null) {
                    buttonList.push({
                        id      : 'document_supprimer',
                        text    : 'Supprimer',
                        i18n    : 'supprimer',
                        icon    : 'fas fa-trash',
                        onclick : 'prepareSupprimer(' + document.get('id') + ', "document")',
                        cls     : 'document_supprimer',
                        priority: 29,
                        badge   : 0,
                        dropdown: ''
                    });
                }
            }
        });
    }
});




