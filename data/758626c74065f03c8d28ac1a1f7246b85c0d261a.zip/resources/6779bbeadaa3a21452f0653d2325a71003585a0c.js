/**
 * Created by thiebault on 24/07/19.
 */
'use strict';
Bs.define('View.User.Password', {
    extend        : 'Bs.View',
    hasStylesheet : false,
    hasTranslation: true,
    options       : {
        passwordMinLength: 6,
        reason           : 'change', // reset (lost), update, init (account creation, SA)
        validToken       : false

    },

    submit: function (e, el) {
        var me = this;
        e.preventDefault();
        if (!me.validateForm(e, el)) {
            return false;
        }
        const $pass = me.$el.find('input[data-id=pass]');
        me.mask();
        if(me.options.reason === 'reset' || me.options.reason === 'init'){
            Bs.Api.patch('/module/lostPassword', { password: $pass.val() }, {
                done  : function () {
                    Bs.View.Alert.Toast.success();
                    me.destroy();
                },
                fail: () => {
                    Bs.View.Alert.Toast.error(Bs.Lang.t('msg_warning_bad_pass'), true);
                },
                always: function () {
                    me.unmask();
                }
            });
        }else{ // reason = change
            Bs.Api.patch('/account/password', { password: $pass.val(), oldPassword: me.$el.find('#current_password').val() }, {
                done  : function () {
                    Bs.View.Alert.Toast.success();
                    me.destroy();
                },
                fail: () => {
                    Bs.View.Alert.Toast.error(Bs.Lang.t('msg_warning_bad_pass'), true);
                },
                always: function () {
                    me.unmask();
                }
            });
        }
    },

    checkRepetition: function (pLen, str) {
        var res = '';
        for (var i = 0; i < str.length; i++) {
            var repeated = true;

            for (var j = 0; j < pLen && (j + i + pLen) < str.length; j++) {
                repeated = repeated && (str.charAt(j + i) == str.charAt(j + i + pLen));
            }
            if (j < pLen) {
                repeated = false;
            }
            if (repeated) {
                i += pLen - 1;
                repeated = false;
            }
            else {
                res += str.charAt(i);
            }
        }
        return res;
    },

    test_force_mdp: function () {
        var me = this;
        var password = $('input[data-id=pass]').val();
        var score = 0;
        //password < 4
        if (password.length < me.options.passwordLength) {
            return 'trop_court';

        }
        else {
            //password length
            score += password.length * 4;
            score += (me.checkRepetition(1, password).length - password.length);
            score += (me.checkRepetition(2, password).length - password.length);
            score += (me.checkRepetition(3, password).length - password.length);
            score += (me.checkRepetition(4, password).length - password.length);

            //password has 3 numbers
            if (password.match(/(.*[0-9].*[0-9].*[0-9])/)) {
                score += 5;
            }
            //password has 2 symbols
            if (password.match(/(.*[!,@#$%^&*?_~].*[!,@#$%^&*?_~])/)) {
                score += 5;
            }
            //password has Upper and Lower chars
            if (password.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/)) {
                score += 10;
            }
            //password has number and chars
            if (password.match(/([a-zA-Z])/) && password.match(/([0-9])/)) {
                score += 15;
            }
            //password has number and symbol
            if (password.match(/([!,@#$%^&*?_~])/) && password.match(/([0-9])/)) {
                score += 15;
            }
            //password has char and symbol
            if (password.match(/([!,@#$%^&*?_~])/) && password.match(/([a-zA-Z])/)) {
                score += 15;
            }
            //password is just a numbers or chars
            if (password.match(/^\w+$/) || password.match(/^\d+$/)) {
                score -= 10;
            }

            if (score < 34) {
                return 'mauvais';
            }
            if (score < 68) {
                return 'bon';
            }
            return 'excellent';
        }
    },

    onPasswordChange       : function () {
        var $password = $('input[data-id=pass]');
        var password = $password.val();
        $password.val(password.trim());
        this.checkSecurityPassword();
    },
    onPasswordConfirmChange: function () {
        var $password = $('input[data-id=confirm]');
        var password = $password.val();
        $password.val(password.trim());
    },

    checkSecurityPassword: function () {
        var niveau = this.test_force_mdp();
        var $force = $('#force');
        switch (niveau) {
            case 'unavailable':
                $force.attr('aria-valuenow', '0');
                $force.width('0%');
                $force.attr('class', 'progress-bar progress-bar-danger');
                $force.html(Bs.Lang.t('unavailable'));
                break;
            case 'trop_court':
                $force.attr('aria-valuenow', '25');
                $force.width('25%');
                $force.attr('class', 'progress-bar progress-bar-danger');
                $force.html(Bs.Lang.t('trop_court'));
                break;
            case 'mauvais':
                $force.attr('aria-valuenow', '50');
                $force.width('50%');
                $force.attr('class', 'progress-bar progress-bar-warning');
                $force.html(Bs.Lang.t('mauvais'));
                break;
            case 'bon':
                $force.attr('aria-valuenow', '75');
                $force.width('75%');
                $force.attr('class', 'progress-bar progress-bar-info');
                $force.html(Bs.Lang.t('bon'));
                break;
            case 'excellent':
                $force.attr('aria-valuenow', '100');
                $force.width('100%');
                $force.attr('class', 'progress-bar progress-bar-success');
                $force.html(Bs.Lang.t('excellent'));
                break;
        }
    },

    checkPasswordConfirmation: function (e, el) {
        var me = this;
        el.setCustomValidity('');
        var $pass = me.$el.find('input[data-id=pass]');
        if ($pass[0].value !== el.value) {
            el.setCustomValidity(Bs.Lang.t('msg_warning_confirm_password'));
        }
    },

    events: {
        'submit .changePwd'            : 'submit',
        'change input[data-id=pass]'   : 'onPasswordChange',
        'change input[data-id=confirm]': 'onPasswordConfirmChange',
        'keyup input[data-id=pass]'    : 'checkSecurityPassword',
        'keyup input[data-id=confirm]' : 'checkPasswordConfirmation'
    }
});
