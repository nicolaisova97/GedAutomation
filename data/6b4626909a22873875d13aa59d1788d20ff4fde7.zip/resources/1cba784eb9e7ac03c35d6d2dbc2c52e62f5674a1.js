/**
 * File description
 *
 * @package
 * @version      :$
 *               :$
 * @link         :$
 * @author       nicolas on 23/03/16
 */
'use strict';
Bs.define('Module.StampManager.View.StampManager', {
	extend        : 'Bs.View.Collection',
	collection    : 'Module.StampManager.Collection.Stamp',
	itemView      : "Module.StampManager.View.Stamp",
	elClass       : 'bootstrap',
	autoMask      : false,
	autoFetch     : true,
	hasStylesheet : false,
	hasTranslation: false,
	options       : {
		type    : null,
		callback: null
	},
	modified      : false,


	afterRender: function () {
        var me = this;
        var view = me.prependItem({ name: 'VU' });
        view.on('ready', function () {
            view.setDefaultStamp();
        });
        me.trigger('ready');
    },

	initialize: function () {
		var me = this;
		var dfd = new $.Deferred();
		me.callParent("initialize").then(function () {
			Bs.Lang.loadNamespaces(['Module/StampDocument/View/StampDocument'], function () {
				dfd.resolve();
			});
		});

		return dfd;
	},

	onAddItem : function(){
		var me = this;
		me.addItem();
	},

	onChangeSelected : function(e, el){
		var me = this;
		var id = $(el).data('id');
		me.mask();
		Bs.Api.patch('/module/stamp/' + id + '/selected', {}, function(){
			me.unmask();
		});

    },


	events: {
		"click #btnAddStamp"        : 'onAddItem',
		"change input[name=selected]"   : 'onChangeSelected'
	}
});
