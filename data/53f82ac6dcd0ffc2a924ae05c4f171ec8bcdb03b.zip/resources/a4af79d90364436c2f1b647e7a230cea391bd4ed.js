Bs.define('Bundle.Account', {
    extend: 'Util.Module',

    initialize: function Bundle () {
        var me = this;
        page('/page/account', function () {
            page.redirect('/page/account/general');
        });

        page('/page/account/:tab?', function (ctx, next) {
            var $nav = $('#mainNav');
            $nav.find('.active').removeClass('active');
            Bs.require('View.User.NavAccount', function (createView) {
                createView({
                    renderTo: $('#main').empty(),
                    tab     : ctx.params.tab
                });
            });
        });

        // Handle Legacy URL
        Application.onReady(function () {
            var url = new Bs.Util.UrlParser();
            var homes = ['/?do=mon_compte', '/index.php?do=mon_compte'];
            var current = url.pathname + url.search;
            if (homes.indexOf(current) >= 0) {
                page.redirect('/page/account');
            }
        });

    }

});




