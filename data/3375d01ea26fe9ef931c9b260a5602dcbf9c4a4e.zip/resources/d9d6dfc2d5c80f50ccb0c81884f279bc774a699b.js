Bs.define('Bundle.Home', {
    extend: 'Util.Module',
    initialize: function Bundle () {
        var me = this;
        page('/page/home', me.renderHome.bind(this));
        Application.onReady(function () {
            var url = new Bs.Util.UrlParser();
            var homes = ['/', '/?do=home', '/index.php', '/index.php?do=home', 'desktop.php', 'mobile.php'];
            var current = url.pathname + url.search;
            if (homes.indexOf(current) >= 0) {
                // when user are viewer(status 6) redirect to ged page and not home page.
                if (My.Profile.getUser().get('profileActive').get('status') === 6) {
                    page.redirect('/index.php?do=ged');
                }
                else {
                    page.redirect('/page/home');
                }
            }
        });
    },

    renderHome: function () {
        if(My.Profile.hasRight('betaUI')){
            Bs.require('Module.Dashboard.View.Dashboard', function(createView){
                createView({
                    renderTo: $('#main').empty()
                });
            });
        }else{
            $('body').attr('id', 'homePage'); // used for style ?
            var $nav = $('#mainNav');
            $nav.children().removeClass('active');
            $nav.find('li a[data-do=home]').parent().addClass('active');

            $.get('/modules/accueil/accueil.php').then(function (html) {
                $('#main').html(html);
                $(document).triggerHandler('page.ready.home');
                // Not using "this" because this => window (called by router)
                Bundle.Home.registerListeners($('#homePageContent'));
            });
        }

    },

    registerListeners: function ($homeCt) {
        $homeCt.on('click', '.btn-file-preservation', function (e) {
            e.preventDefault();
            Bs.require(['Bs.View.Modal', 'View.UsefulInfo.FilePreservation'], function () {
                Bs.create('Bs.View.Modal', {
                    view : 'View.UsefulInfo.FilePreservation',
                    title: Bs.Lang.t('FilePreservation'),
                    size : 'lg'
                });
            });
            return false;
        });

        $homeCt.on('click', '.btn-legislation', function (e) {
            e.preventDefault();
            Bs.require(['Bs.View.Modal', 'View.UsefulInfo.Legislation'], function () {
                Bs.create('Bs.View.Modal', {
                    view : 'View.UsefulInfo.Legislation',
                    title: Bs.Lang.t('Legislation'),
                    size : 'lg'
                });
            });
            return false;
        });
    }

});

function affichePopupAccueil (popup) {
    TINY.box.show({
        url   : '../../modules/accueil/popup/' + popup + '.popup.php',
        openjs: function () {
            tinyBoxTricks();
            if (popup === 'cgu') {
                $('.tcontent').find('.panel-footer').hide();
            }
        }
    });
}




