Bs.define('Module.Dashboard.View.Dashboard', {
    extend        : 'Bs.View',
    hasTranslation: true,
    hasStylesheet : false,
    data          : {
        viewEnabled    : {
            left : [],
            right: []
        },
        additionalViews: []
    },
    afterRender: () => {
        window.dispatchEvent(new CustomEvent('loadReact'));
    }
});
