'use strict';

Bs.define('Bundle.Folder.App', {
    extend: 'Util.Module',

    initialize: function Bundle () {
        var me = this;

        me.handleEvents();
    },

    handleEvents: function () {
        $(document).on('actions.folder', function (e, buttonList, folder) {

            // const rights
            const renameFolder = (!folder.isRoot() && (folder.hasRight('renommerDossier') || My.Profile.isAuthorizedToByPass('renommerDossier')));
            const moveFolder = (!folder.isRoot() && (folder.hasRight('deplacerDossier') || My.Profile.isAuthorizedToByPass('deplacerDossier')));

            if (folder.isRoot() && My.Profile.hasRight('remplirDossier')
                || !folder.isRoot() && folder.hasRight('remplirDossier')) {
                buttonList.push({
                    title  : 'upload',
                    i18nKey: 'depot_fichier',
                    icon   : 'fas fa-cloud-upload-alt',
                    priority: 1
                });
            }
            if (folder.isRoot() && My.Profile.hasRight('documentDownload')) {
                buttonList.push({
                    title  : 'downloadAllUnclassified',
                    i18nKey: 'downloadAllUnclassified',
                    icon   : 'fas fa-file-archive',
                    priority: 2
                });
            }
            if ((folder.isRoot() && My.Profile.hasRight('folderCreateRoot'))
                || (!folder.isRoot() && folder.hasRight('creationDossier'))
                || My.Profile.isAuthorizedToByPass('creationDossier')
            ) {
                buttonList.push({
                    title  : 'newFolder',
                    i18nKey: 'nouveau_dossier',
                    icon   : 'fas fa-folder-plus',
                    onclick: 'prepareAjoutDossier(' + folder.get('id') + ', "dossier")',
                    priority: 5
                });
            }

            if (renameFolder) {
                buttonList.push({
                    title  : 'dossier_renommer',
                    i18nKey: 'renommer',
                    icon   : 'fas fa-pencil-alt',
                    onclick: 'prepareRenommer(' + folder.get('id') + ', "dossier")',
                    priority: 9
                });
            }
            if (moveFolder) {
                buttonList.push({
                    title  : 'folderMove',
                    i18nKey: 'move',
                    icon   : 'fas fa-arrows-alt',
                    priority: 7
                });
            }
            // Delete Btn : no root, with "supprimerDossier" right, no "contract" folder type
            if ((!folder.isRoot() && folder.hasRight('supprimerDossier') && !folder.isTypeContract()) || My.Profile.isAuthorizedToByPass('supprimerDossier') && !folder.isRoot()) {
                buttonList.push({
                    title  : 'dossier_supprimer',
                    i18nKey: 'supprimer',
                    icon   : 'fas fa-trash',
                    onclick: 'prepareSupprimer(' + folder.get('id') + ', "dossier")',
                    priority: 14
                });
            }
        });
    }
});




